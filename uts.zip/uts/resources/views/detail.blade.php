<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dropdowns.css" rel="stylesheet">
    <link href="css/home.css" rel="stylesheet">
    <title>Home</title>
</head>
<body>
    <div class=" BANNER px-4 py-5 text-center">
      <h1 style="color: white">Happy Book Store</h1>
    </div>
    <div class="container">
        <header class="d-flex justify-content-center py-3">
          <ul class="nav nav-pills">
            <li class="nav-item"><a href="#" class="nav-link active" aria-current="page">Home</a></li>
            <li class="nav-item"><a href="#" class="nav-link">Category</a></li>
            <li class="nav-item"><a href="#" class="nav-link">Contact</a></li>
          </ul>
        </header>
      </div>
      
      <div class="container-table">
        <article class="blog-post" style="padding-left: 10%">
          <h2 class="blog-post-title">Store address</h2>
          <p>Title: I want to eat your appendix</p>
          <p>Author: 70Menit</p>
          <p>Publisher:70Menit Publisher</p>
          <p>Year: 2002 </p>
          <p>Description:</p>
          <p>A high school student discovers one of his classmates, Sakura Yamauchi, is suffering from a terminal illness. This secret brings the two together, as she lives out her final moments.</p>
        </article>
        <<div class="col">
          @foreach ($categories as $category)
          <div style="width: 100%;">
            <a href="">{{ $category->category }}</a>
          </div>  
          @endforeach
        </div>
      </div>

      <div class="container">
        <footer class="py-3 my-4">
          <ul class="nav justify-content-center border-bottom pb-3 mb-3">
            <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Home</a></li>
            <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Category</a></li>
            <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Contact</a></li>
          </ul>
          <p class="text-center text-muted">&copy; Happy Book Store ltd.</p>
        </footer>
      </div>
      
</html>