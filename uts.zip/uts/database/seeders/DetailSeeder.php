<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Detail;

class DetailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Detail::create([
            
            'book_id'=>1,
            'author'=>'Daffa Rizki',
            'publisher'=>'Pemuda punya karya',
            'year'=>2020,
            'description'=>'The melancholy life of Bryan BT Theophilus as a thirdwheel'
         ]);

         Detail::create([
            
            'book_id'=>2,
            'author'=>'Daffa Rizki',
            'publisher'=>'Pemuda punya karya',
            'year'=>2018,
            'description'=>'What is true love?'
         ]);

         Detail::create([
            'book_id'=>3,
            'author'=>'Christophe',
            'publisher'=>'valve',
            'year'=>2002,
            'description'=>'The cult who shocks the world'
         ]);

         Detail::create([
            'book_id'=>4,
            'author'=>'Christophe',
            'publisher'=>'valve',
            'year'=>2002,
            'description'=>'I got killed and reincarnated as a goat'
         ]);

         Detail::create([
            'book_id'=>5,
            'author'=>'70Menit',
            'publisher'=>'70Menit Publisher',
            'year'=>2005,
            'description'=>'The classic tale of jason and the argonauts'
         ]);

         Detail::create([
            'book_id'=>6,
            'author'=>'70Menit',
            'publisher'=>'70Menit Publisher',
            'year'=>2002,
            'description'=>'A high school student discovers one of his classmates, Sakura Yamauchi, is suffering from a terminal illness. This secret brings the two together, as she lives out her final moments.'
         ]);

         Detail::create([
            'book_id'=>7,
            'author'=>'Cporzee',
            'publisher'=>'GoatBooks',
            'year'=>2012,
            'description'=>'alright steady pom pi pi'
         ]);

         Detail::create([
            'book_id'=>8,
            'author'=>'Cporzee',
            'publisher'=>'GoatBooks',
            'year'=>2002,
            'description'=>'Sometime in life you justt need to not give a f'
         ]);

         Detail::create([
            'book_id'=>9,
            'author'=>'Orion',
            'publisher'=>'ORN',
            'year'=>2014,
            'description'=>'Travel the mysterious aghanim labyrinth'
         ]);

         Detail::create([
            'book_id'=>10,
            'author'=>'Orion',
            'publisher'=>'valve',
            'year'=>2002,
            'description'=>'Feel the force luke'
         ]);
    }
}
