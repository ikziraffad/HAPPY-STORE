<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Book;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Book::create([
            'title'=>'The unwritten story of BT : The greatest fly in the world',
            'category_id'=>7
         ]);

        Book::create([
            'title'=>'Rizaly & Maharani',
            'category_id'=>7
         ]);

         Book::create([
            'title'=>'TFG : The cult that brings a new light',
            'category_id'=>4
         ]);

         Book::create([
            'title'=>'That Time I Got Reincarnated as a GOAT',
            'category_id'=>4
         ]);

         Book::create([
            'title'=>'jason and the argonauts',
            'category_id'=>8
         ]);

         Book::create([
            'title'=>'I want to eat your appendix',
            'category_id'=>7
         ]);

         Book::create([
            'title'=>'WebProg for Dummies',
            'category_id'=>2
         ]);

         Book::create([
            'title'=>'The subtle art of not giving an f',
            'category_id'=>5
         ]);

         Book::create([
            'title'=>'Aghanims Labyrinth',
            'category_id'=>4
         ]);

         Book::create([
            'title'=>'Sentrifugal Force',
            'category_id'=>1
         ]);
    }
}
