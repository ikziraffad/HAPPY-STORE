<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        $categories = ['Fiction','Science','Computer','Fantasy','Religious','Motivational','Non-Fiction','Romance Comedy','Classic','Sci-Fi'];
        for ($i=0; $i < count($categories) ; $i++){ 
            # code...
            Category::create([
               'category'=>$categories[$i]
            ]);
        }
    }
}
