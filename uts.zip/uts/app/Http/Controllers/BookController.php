<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use App\Models\Category;

class BookController extends Controller
{
    //
    public function get_Books(){
        $books = Book::all();
        $categories=Category::all();
        return view('home',compact('books','categories'));
    }


}
