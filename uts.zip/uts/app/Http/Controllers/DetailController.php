<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Book;

use Illuminate\Http\Request;

class DetailController extends Controller
{
    //
    public function getDetail(){
        $detail = detail::find($book);
        $category = Category::all();

        return view('detail',compact('detail','categories'));
    }
}
